//
//  PlayerTool.h
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerTool : UITableViewCell
+(NSArray *)getAllPlayers:(id)respond;
+(NSArray*)getALLTR:(id)respond;
+(NSArray*)getALLTomorrow:(id)respond;
+(NSArray*)getALLYesterday:(id)respond;
+(NSArray*)getALLTeamInfo:(id)respond;
+(NSArray *)getPlayer:(id)respond;

@end
