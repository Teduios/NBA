//
//  Player.m
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "Player.h"

@implementation Player
+(Player *)getplayer:(NSDictionary *)dic
{
    Player *play = [[Player alloc]init];
    play.title = dic[@"title"];
    play.player1 = dic[@"player1"];
    play.player1info = dic[@"player1info"];
    play.player1location = dic[@"player1location"];
    play.player1logobig = dic[@"player1logobig"];
    play.player1url = dic[@"player1url"];
    

    play.player2 = dic[@"player2"];
    play.player2info = dic[@"player2info"];
    play.player2location = dic[@"player2location"];
    play.player2logobig = dic[@"player2logobig"];
    play.player2url = dic[@"player2url"];

    play.status = dic[@"status"];
    play.score = dic[@"score"];
    
    return play;


}
+(Player *)getAPlayer:(NSDictionary *)dic
{
    Player *play = [[Player alloc]init];
    play.url1 = dic[@"url1"];
    return play;


}
@end
