//
//  Team.h
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Team : NSObject
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *url;
+(Team*)getATeamInfo:(NSDictionary*)dic;
@end
