//
//  Team.m
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "Team.h"

@implementation Team
+(Team *)getATeamInfo:(NSDictionary *)dic
{
    Team *team = [[Team alloc]init];
    team.name = dic[@"name"];
    team.url = dic[@"url"];
    
    return  team;



}

@end
