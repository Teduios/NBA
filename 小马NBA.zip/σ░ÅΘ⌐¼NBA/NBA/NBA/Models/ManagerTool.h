//
//  ManagerTool.h
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^success)(id respond);
typedef void(^failure)(NSError *errof);
@interface ManagerTool : NSObject
+(void)getallPlayerList:(success)successful and:(failure)faile and:(NSDictionary*)parameter ;
@end
