//
//  TR.m
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "TR.h"

@implementation TR
+(TR *)getATRInfo:(NSDictionary *)dic
{
    TR *tr =[[TR alloc]init];
    tr.link1text = dic[@"link1text"];
    tr.link1url = dic[@"link1url"];
    tr.player1 = dic[@"player1"];
    tr.player1logo = dic[@"player1logo"];
    tr.player2 = dic[@"player2"];
    tr.player2logo = dic[@"player2logo"];
    tr.score = dic[@"score"];
    tr.status = dic[@"status"];
    tr.time = dic[@"time"];
    

    return tr;


}
@end
