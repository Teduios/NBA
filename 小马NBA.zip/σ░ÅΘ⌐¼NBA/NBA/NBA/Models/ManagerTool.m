//
//  ManagerTool.m
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ManagerTool.h"
#import "AFNetworking.h"

@implementation ManagerTool
+(void)getallPlayerList:(success)successful and:(failure)faile and:(NSDictionary *)parameter
{

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"http://op.juhe.cn/onebox/basketball/nba?key=938898623a6770cf7b9bbbbc9e677e56" parameters:parameter progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        successful(responseObject);
       
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        faile(error);
        
    }];


}
@end
