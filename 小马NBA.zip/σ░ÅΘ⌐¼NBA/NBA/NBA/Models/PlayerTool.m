//
//  PlayerTool.m
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "PlayerTool.h"
#import "ManagerTool.h"
#import "Player.h"
#import "TR.h"
#import "Team.h"

@implementation PlayerTool
+(NSArray *)getAllPlayers:(id)respond
{
    NSMutableArray *arr = [NSMutableArray array];
    NSArray *array =respond[@"result"][@"list"][1][@"live"];
    for (NSDictionary *dic in array ) {
        Player *player =[Player getplayer:dic];
        [arr addObject:player];
        
    }
    return [arr copy];

}
+(NSArray *)getALLTR:(id)respond
{
 NSMutableArray *arr = [NSMutableArray array];
    NSDictionary *dict =respond[@"result"][@"list"][1];
    for (NSDictionary *dic in dict[@"tr"]) {
        TR *tr = [TR getATRInfo:dic];
            [arr addObject:tr];
            
            
        
    }
    
    return  arr;

}
+(NSArray *)getALLTomorrow:(id)respond
{

    NSMutableArray *arr = [NSMutableArray array];
    NSDictionary *dict =respond[@"result"][@"list"][2];
    for (NSDictionary *dic in dict[@"tr"]) {
        TR *tr = [TR getATRInfo:dic];
        [arr addObject:tr];
    }
    return  [arr copy];
}
+(NSArray *)getALLYesterday:(id)respond
{

    
    NSMutableArray *arr = [NSMutableArray array];
    NSDictionary *dict =respond[@"result"][@"list"][0];
    for (NSDictionary *dic in dict[@"tr"]) {
        TR *tr = [TR getATRInfo:dic];
        [arr addObject:tr];
    }
    return  [arr copy];


}
+(NSArray *)getALLTeamInfo:(id)respond
{
     NSMutableArray *arr = [NSMutableArray array];
 NSArray *array =respond[@"result"][@"teammatch"];
    for (NSDictionary *dic in array) {
        Team *team = [Team getATeamInfo:dic];
        [arr addObject:team];
    }
    

    return  arr ;

}
+(NSArray *)getPlayer:(id)respond
{

    NSMutableArray *arr = [NSMutableArray array];
    NSArray *array =respond[@"result"][@"list"][1][@"livelink"];
    for (NSDictionary *dic in array ) {
        Player *player =[Player getplayer:dic];
        [arr addObject:player];
        
       
        
        
    }
    
     return  arr;


}
@end
