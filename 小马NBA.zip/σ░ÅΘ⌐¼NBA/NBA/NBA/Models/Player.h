//
//  Player.h
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Player : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *player1;
@property(nonatomic,strong)NSString *player1info;
@property(nonatomic,strong)NSString *player1location;
@property(nonatomic,strong)NSString *player1logobig;
@property(nonatomic,strong)NSString *player1url;
@property(nonatomic,strong)NSString *player2;
@property(nonatomic,strong)NSString *player2info;
@property(nonatomic,strong)NSString *player2location;
@property(nonatomic,strong)NSString *player2logobig;
@property(nonatomic,strong)NSString *player2url;
@property(nonatomic,strong)NSString *score;
@property(nonatomic)NSNumber *status;
@property(nonatomic,strong)NSString *url1;
+(Player*)getplayer:(NSDictionary *)dic;
+(Player*)getAPlayer:(NSDictionary*)dic;








@end
