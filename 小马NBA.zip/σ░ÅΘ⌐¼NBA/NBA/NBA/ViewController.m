//
//  ViewController.m
//  NBA
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"
#import "LeftViewController.h"
#import "RESideMenu.h"
#import "ManagerTool.h"
#import "Player.h"
#import "PlayerTool.h"
#import "ATableViewCell.h"
#import "TR.h"
#import "BTableViewCell.h"
#import "WebViewController.h"
#import "MJRefresh.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSArray *allPlayerList;
@property(nonatomic,strong)NSArray *APlayTV;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSArray *allTRInfo;

@end

@implementation ViewController
-(NSArray *)APlayTV
{
    if (!_APlayTV) {
        [ManagerTool getallPlayerList:^(id respond) {
            _APlayTV = [PlayerTool getPlayer:respond];
       
            [self.tableView reloadData];
        } and:^(NSError *errof) {
            
        } and:nil];
    }
    return _APlayTV;

}
-(NSArray *)allPlayerList
{
    if (!_allPlayerList) {
       [ManagerTool getallPlayerList:^(id respond) {
          _allPlayerList =  [PlayerTool getAllPlayers:respond];
            NSLog(@"接收到数据");
           [self.tableView reloadData];
       } and:^(NSError *errof) {
           NSLog(@"报错了");
       } and:nil];
        
    }
    return _allPlayerList;

}
-(NSArray *)allTRInfo
{

    if (!_allTRInfo) {
        [ManagerTool getallPlayerList:^(id respond) {
            _allTRInfo = [PlayerTool getALLTR:respond];
                [self.tableView reloadData];
        } and:^(NSError *errof) {
            
        } and:nil];
    }
    return  _allTRInfo;

}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.tableView.delegate = self;
//    self.tableView.dataSource = self;
    [self setupRefresh];


    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)clickButton:(id)sender {
//    LeftViewController *left = [[LeftViewController alloc]init];
//    LeftViewController *left = [self.storyboard instantiateViewControllerWithIdentifier:@"left"];    
//    [self presentViewController:left animated:YES completion:nil];
    [self.sideMenuViewController presentLeftMenuViewController];


}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return self.allPlayerList.count;
    }
    else
    {
        return  self.allTRInfo.count;
    
    }
        
 

}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        ATableViewCell *cell =[tableView dequeueReusableCellWithIdentifier: @"cell" forIndexPath:indexPath];
        Player *player = self.allPlayerList[indexPath.row];
        cell.player = player;
           return cell;

    }
    else
    {
        BTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell1" forIndexPath:indexPath];
        
        TR *tr = self.allTRInfo[indexPath.row];
        cell.tr = tr;
           return cell;
        
    }


}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 170;
    }
    else
    {
    
        return 150;
    }
    

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        Player *player =self.APlayTV[0];
        WebViewController *webView = [[WebViewController alloc]init];
        webView.url = player.url1;
        [self presentViewController:webView animated:YES completion:nil];
    }

    else
    {
    
        TR *tr= self.allTRInfo[indexPath.row];
        WebViewController *webView = [[WebViewController alloc]init];
        webView.url = tr.link1url;
        [self presentViewController:webView animated:YES completion:nil];
    
    
    }


}
-(void)setupRefresh
{
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    
    // 马上进入刷新状态
    [self.tableView.mj_header beginRefreshing];

//    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
//    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
//    // 设置普通状态的动画图片
//    [header setImages:idleImages forState:MJRefreshStateIdle];
//    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
//    [header setImages:pullingImages forState:MJRefreshStatePulling];
//    // 设置正在刷新状态的动画图片
//    [header setImages:refreshingImages forState:MJRefreshStateRefreshing];
//    // 设置header
//    self.tableView.mj_header = header;

}
-(void)refresh
{
    [self.tableView reloadData];
    [self.tableView.mj_header endRefreshing];


}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return @"今日热点";
    }
    else
    {
    return @"直播列表";
    
    
    }


}
@end
