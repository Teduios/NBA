//
//  LeftViewController.h
//  NBA
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"

@interface LeftViewController : ViewController

@end
