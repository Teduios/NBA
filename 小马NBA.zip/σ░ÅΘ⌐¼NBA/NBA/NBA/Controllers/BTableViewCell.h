//
//  BTableViewCell.h
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TR.h"

@interface BTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *dating;
@property (weak, nonatomic) IBOutlet UIImageView *aImage;
@property (weak, nonatomic) IBOutlet UILabel *teamName;
@property (weak, nonatomic) IBOutlet UILabel *score;
@property (weak, nonatomic) IBOutlet UIImageView *bImage;
@property (weak, nonatomic) IBOutlet UILabel *teamName2;
@property (weak, nonatomic) IBOutlet UILabel *zhibo;

@property(nonatomic,strong)TR*tr;
@end
