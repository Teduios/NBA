//
//  LeftViewController.m
//  NBA
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LeftViewController.h"
#import "MBProgressHUD+KR.h"

@interface LeftViewController ()<UIWebViewDelegate>
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;
@property(nonatomic,strong)UIWebView *web;

@end

@implementation LeftViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

   
}
- (IBAction)clickButton:(UIButton*)sender {
    UIViewController *controller = [[UIViewController alloc]init];
    self.web = [[UIWebView alloc]initWithFrame:CGRectMake(0, 50, self.view.bounds.size.width, self.view.bounds.size.height)];
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 50)];
    

    
    [button addTarget:self action:@selector(back) forControlEvents:(UIControlEventTouchUpInside)];
   

    [button setContentEdgeInsets:UIEdgeInsetsMake(24, 0, 0, 0)];
    button.backgroundColor = [UIColor redColor];
   
    [button setTitle:@"蓦然回首" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.web.delegate = self;
    [controller.view  addSubview:self.web];
    [controller.view addSubview:button];
  
    NSInteger index = [self.buttons indexOfObject:sender];
    switch (index) {
        case 0:{
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://sports.qq.com/nba/schedule/?ptag=360.onebox.schedule.nba"]];
            [self.web loadRequest:request];
            [self presentViewController:controller animated:YES completion:nil];
        }
            break;
        case 1:
        {
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://sports.qq.com/nba/schedule/?ptag=360.onebox.schedule.nba"]];
            [self.web loadRequest:request];
            [self presentViewController:controller animated:YES completion:nil];
        }
            
            break;
        case 2:
        {
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://nbadata.sports.qq.com/stats/player/2015playerstatsindex.html?ptag=360.onebox.schedule.nba"]];
            [self.web loadRequest:request];
            [self presentViewController:controller animated:YES completion:nil];
        }
            
            break;
            
        default:
        {
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://sports.qq.com/fans/group.htm?mid=69"]];
            [self.web loadRequest:request];
            [self presentViewController:controller animated:YES completion:nil];
        }
            break;
     }
    }
    

-(void)webViewDidStartLoad:(UIWebView *)webView
{
    [MBProgressHUD showMessage:@"正在拼命加载..."];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];

}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [MBProgressHUD hideHUD];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{

    [MBProgressHUD hideHUD];
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@" 请求失败" message:@"请稍后再试" preferredStyle:(UIAlertControllerStyleAlert)];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];}];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];

}
-(void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];


}

@end
