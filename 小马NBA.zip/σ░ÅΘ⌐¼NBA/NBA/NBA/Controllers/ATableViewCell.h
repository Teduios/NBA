//
//  ATableViewCell.h
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Player.h"

@interface ATableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *timeBegin;
@property (weak, nonatomic) IBOutlet UILabel *score;
@property (weak, nonatomic) IBOutlet UILabel *movie;
@property (weak, nonatomic) IBOutlet UIImageView *iamgeView;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *winTime;

@property (weak, nonatomic) IBOutlet UIImageView *imageVIew2;
@property (weak, nonatomic) IBOutlet UILabel *home2;
@property (weak, nonatomic) IBOutlet UILabel *wintime2;
@property (weak, nonatomic) IBOutlet UILabel *name2;

@property (weak, nonatomic) IBOutlet UILabel *home;

@property(nonatomic,strong)Player*player;

@end
