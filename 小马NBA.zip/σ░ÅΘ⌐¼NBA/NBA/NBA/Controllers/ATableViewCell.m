//
//  ATableViewCell.m
//  NBA
//
//  Created by tarena on 16/2/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ATableViewCell.h"
#import "UIImageView+WebCache.h"
#import "SDImageCache.h"

@implementation ATableViewCell
-(void)setPlayer:(Player *)player
{
    _player = player;
    self.timeBegin.text = player.title;
    self.score.text = player.score;
   // self.movie.text = player.player1url;
   // self.iamgeView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:player.player1logobig]]];
    [self.iamgeView sd_setImageWithURL:[NSURL URLWithString:player.player1logobig]];
    self.name.text = player.player1;
    self.home.text = player.player1location;
    self.winTime.text = player.player1info;
//    self.imageVIew2.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:player.player2logobig]]];
    [self.imageVIew2 sd_setImageWithURL:[NSURL URLWithString:player.player2logobig]];
    self.home2.text = player.player2location;
    self.wintime2.text = player.player2info;
    

    
    
    



}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
