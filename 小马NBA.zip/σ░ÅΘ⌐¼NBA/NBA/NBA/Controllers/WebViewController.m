//
//  WebViewController.m
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "WebViewController.h"
#import "MBProgressHUD+KR.h"
#import "MJRefreshHeader.h"
#import "MJRefresh.h"

@interface WebViewController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation WebViewController
- (IBAction)refresh:(id)sender {
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.webView.delegate = self;
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.url]];
    
    [self.webView loadRequest:request];
    [self setupRefresh];
   
}


- (IBAction)backButton:(id)sender {
}
- (IBAction)goOnButton:(id)sender {
}
- (IBAction)refreshButton:(id)sender {
    
    [self setupRefresh];
}
- (IBAction)backItem:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}



-(void)webViewDidStartLoad:(UIWebView *)webView
{
//    [MBProgressHUD showMessage:@"正在拼命加载..."];
    [MBProgressHUD showMessage:@"正在拼命加载..." toView:self.webView];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
//    [MBProgressHUD hideHUD];
    [MBProgressHUD hideHUDForView:self.webView animated:YES];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [MBProgressHUD hideHUD];
//    [MBProgressHUD hideHUD];
    [MBProgressHUD hideHUDForView:self.webView animated:YES];
  //  [MBProgressHUD showError:@"失败"];
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"请求超时" message:@"请稍后再试" preferredStyle:(UIAlertControllerStyleAlert)];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
       // [self dismissViewControllerAnimated:YES completion:nil]
        ;}];
    [alert addAction:action];
    //[self presentViewController:alert animated:YES completion:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
    
}
-(void)setupRefresh
{
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    self.webView.scrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    
    // 马上进入刷新状态
    [self.webView.scrollView.mj_header beginRefreshing];
    
    //    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    //    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    //    // 设置普通状态的动画图片
    //    [header setImages:idleImages forState:MJRefreshStateIdle];
    //    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    //    [header setImages:pullingImages forState:MJRefreshStatePulling];
    //    // 设置正在刷新状态的动画图片
    //    [header setImages:refreshingImages forState:MJRefreshStateRefreshing];
    //    // 设置header
    //    self.tableView.mj_header = header;
    
}
-(void)refresh
{
    [self.webView  reloadInputViews];
    [self.webView.scrollView.mj_header endRefreshing];
    
    
}
@end
