//
//  BTableViewCell.m
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "BTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation BTableViewCell
-(void)setTr:(TR *)tr
{
    _tr = tr;
    self.dating.text = tr.time;
//    self.aImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:tr.player1logo]]];
    [self.aImage sd_setImageWithURL:[NSURL URLWithString:tr.player1logo]];
    self.teamName.text = tr.player1;
    self.score.text = tr.score;
//    self.bImage.image =[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:tr.player2logo]]];
    [self.bImage sd_setImageWithURL:[NSURL URLWithString:tr.player2logo]];
    self.teamName2.text = tr.player2;
    self.zhibo.text = tr.link1text;
    


}
- (void)awakeFromNib {
   
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
