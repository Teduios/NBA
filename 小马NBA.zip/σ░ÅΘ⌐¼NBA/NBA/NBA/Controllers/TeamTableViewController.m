//
//  TeamTableViewController.m
//  NBA
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "TeamTableViewController.h"
#import "Team.h"
#import "PlayerTool.h"
#import "ManagerTool.h"
#import "WebViewController.h"
#import "MBProgressHUD+KR.h"
#import "MJRefresh.h"

@interface TeamTableViewController ()
@property(nonatomic,strong)NSArray *allTeamInfo;

@end

@implementation TeamTableViewController
-(NSArray *)allTeamInfo
{
    if (!_allTeamInfo) {
        [ManagerTool getallPlayerList:^(id respond) {
            _allTeamInfo = [PlayerTool getALLTeamInfo:respond];
            [self.tableView reloadData];
        } and:^(NSError *errof) {
            
        } and:nil];
    }

    return  _allTeamInfo;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupRefresh];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}
-(void)webViewDidStartLoad:(UIWebView *)webView
{
    [MBProgressHUD showMessage:@"正在拼命加载..."];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [MBProgressHUD hideHUD];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    
    [MBProgressHUD hideHUD];
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"请求超时" message:@"请稍后再试" preferredStyle:(UIAlertControllerStyleAlert)];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //[self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.allTeamInfo.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell4"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle: UITableViewCellStyleDefault reuseIdentifier:@"cell4"];
    }
    Team *team = self.allTeamInfo[indexPath.row];
    cell.textLabel.text =team.name;
    cell.backgroundColor = [UIColor colorWithRed:(indexPath.row+5)/25.5 green:(indexPath.row+1)/25.5 blue:0.3 alpha:1];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    Team *team = self.allTeamInfo[indexPath.row];
    WebViewController *webView = [[WebViewController alloc]init];
    webView.url = team.url;
    [self presentViewController:webView animated:YES completion:nil];



}
-(void)setupRefresh
{
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    
    // 马上进入刷新状态
    [self.tableView.mj_header beginRefreshing];
    
    //    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    //    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    //    // 设置普通状态的动画图片
    //    [header setImages:idleImages forState:MJRefreshStateIdle];
    //    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    //    [header setImages:pullingImages forState:MJRefreshStatePulling];
    //    // 设置正在刷新状态的动画图片
    //    [header setImages:refreshingImages forState:MJRefreshStateRefreshing];
    //    // 设置header
    //    self.tableView.mj_header = header;
    
}
-(void)refresh
{
    [self.tableView reloadData];
    [self.tableView.mj_header endRefreshing];
    
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
